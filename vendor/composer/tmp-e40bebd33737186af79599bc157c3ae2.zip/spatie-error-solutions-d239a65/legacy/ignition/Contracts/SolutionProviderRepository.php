<?php

namespace Spatie\Ignition\Contracts;

interface SolutionProviderRepository extends \Spatie\ErrorSolutions\Contracts\SolutionProviderRepository
{

}
