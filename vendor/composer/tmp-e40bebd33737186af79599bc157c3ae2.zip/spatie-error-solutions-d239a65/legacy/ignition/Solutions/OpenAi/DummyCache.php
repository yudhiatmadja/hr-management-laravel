<?php

namespace Spatie\Ignition\Solutions\OpenAi;

class DummyCache extends \Spatie\ErrorSolutions\Solutions\OpenAi\DummyCache
{

}
