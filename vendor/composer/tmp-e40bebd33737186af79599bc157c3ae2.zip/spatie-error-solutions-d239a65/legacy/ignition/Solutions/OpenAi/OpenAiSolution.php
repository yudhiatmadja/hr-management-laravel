<?php

namespace Spatie\Ignition\Solutions\OpenAi;

use Spatie\Ignition\Contracts\Solution;

class OpenAiSolution extends \Spatie\ErrorSolutions\Solutions\OpenAi\OpenAiSolution implements Solution
{

}
