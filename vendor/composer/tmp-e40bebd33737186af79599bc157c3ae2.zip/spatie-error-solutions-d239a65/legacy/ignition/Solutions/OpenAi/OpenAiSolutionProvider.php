<?php

namespace Spatie\Ignition\Solutions\OpenAi;

use Spatie\Ignition\Contracts\HasSolutionsForThrowable;

class OpenAiSolutionProvider extends \Spatie\ErrorSolutions\Solutions\OpenAi\OpenAiSolutionProvider implements HasSolutionsForThrowable
{

}
