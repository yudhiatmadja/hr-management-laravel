<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\SuggestImportSolution as BaseSuggestImportSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class SuggestImportSolution extends BaseSuggestImportSolutionAlias  implements Solution
{

}
