<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\UseDefaultValetDbCredentialsSolution as BaseUseDefaultValetDbCredentialsSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class UseDefaultValetDbCredentialsSolution extends BaseUseDefaultValetDbCredentialsSolutionAlias implements Solution
{

}
