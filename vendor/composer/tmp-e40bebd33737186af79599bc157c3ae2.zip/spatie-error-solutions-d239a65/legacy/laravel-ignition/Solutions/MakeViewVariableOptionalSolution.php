<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\MakeViewVariableOptionalSolution as BaseMakeViewVariableOptionalSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class MakeViewVariableOptionalSolution extends BaseMakeViewVariableOptionalSolutionAlias implements Solution
{

}
