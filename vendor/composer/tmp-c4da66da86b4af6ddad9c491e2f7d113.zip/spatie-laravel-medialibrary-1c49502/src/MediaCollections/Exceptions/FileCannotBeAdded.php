<?php

namespace Spatie\MediaLibrary\MediaCollections\Exceptions;

use Exception;

abstract class FileCannotBeAdded extends Exception {}
